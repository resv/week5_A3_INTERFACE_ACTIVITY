package week5_A3_INTERFACE_ACTIVITY;

public interface LibraryUser {

//	AN INTERFACE DOES NOT NEED TO BE DEFINED WITH A BLOCK, THESE ARE JUST CONTRACTS
		public void registerAccount(int age);
		public void requestBook(String bookType);
	
}
